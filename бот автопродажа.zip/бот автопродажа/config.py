TOKEN = 'токен от ботфазер'
API_TOKEN = 'токен криптобот'
ADMIN_ID = айди админа
DATABASE_NAME = 'userdata.db'

# ЮMoney настройки
YOOMONEY_RECEIVER = ''  # Ваш номер кошелька ЮMoney, очень важно! если вы ошиблись и неверно списали номер карты в юмани, деньги вам не придут
YOOMONEY_API_TOKEN = (
    'токен он юмани'
)

# CryptoBot настройки
CRYPTOPAY_API_TOKEN = 'еще раз сюда токен криптобот'  # Ваш API токен CryptoBot